//
//  QNTrack.h
//  QNRTCKit
//
//  Created by 何云旗 on 2021/12/29.
//  Copyright © 2021 Pili Engineering, Qiniu Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QNTypeDefines.h"
#import "QNVideoGLView.h"

NS_ASSUME_NONNULL_BEGIN

#pragma mark -- QNTrack
/*!
 * @abstract 用来描述一路 Track 的相关信息
 *
 * @discussion 主要用于发布/订阅时传入 Track 相关的信息，或者远端 Track 状态变更时 SDK 回调给 App Track 相关的信息。
 *
 * @since v4.0.0
 */
@interface QNTrack : NSObject

/*!
 * @abstract 用户的唯一标识。
 *
 * @since v4.0.0
 */
@property (nonatomic, readonly) NSString *userID;

/*!
 * @abstract 一路 Track 在 Server 端的唯一标识。
 *
 * @discussion 发布成功时由 SDK 自动生成，订阅/Mute 等操作依据此 trackId 来确定相应的 Track。
 *
 * @since v4.0.0
 */
@property (nonatomic, readonly) NSString *trackID;

/*!
 * @abstract 标识该路 Track 是音频还是视频。
 *
 * @discussion 发布时由 SDK 根据 sourceType 确定。
 *
 * @see QNTrackKind，QNRTCSourceType
 *
 * @since v4.0.0
 */
@property (nonatomic, readonly) QNTrackKind kind;

/*!
 * @abstract Track 的 tag，SDK 会将其透传到远端，当发布多路视频 Track 时可用 tag 来作区分。
 *
 * @since v4.0.0
 */
@property (nonatomic, readonly) NSString *tag;

/*!
 * @abstract 标识 Track 是否为 mute 状态
 *
 * @since v4.0.0
 */
@property (nonatomic, assign, readonly) BOOL muted;

- (instancetype)init NS_UNAVAILABLE;

@end

#pragma mark -- QNLocalTrack
@interface QNLocalTrack : QNTrack

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 将本地音/视频 Track 置为 muted 状态。
 *
 * @discussion 需要发布成功后才可以执行 mute 操作。
 *
 * @since v4.0.0
 */
- (void)updateMute:(BOOL)muted;

- (void)destroy;

@end
@class QNLocalAudioTrack;
@protocol QNLocalAudioTrackDelegate <NSObject>

@optional
/*!
 * @abstract 音频 Track 数据回调。
 *
 * @since v4.0.0
 */
- (void)localAudioTrack:(QNLocalAudioTrack *)localAudioTrack didGetAudioBuffer:(AudioBuffer *)audioBuffer bitsPerSample:(NSUInteger)bitsPerSample sampleRate:(NSUInteger)sampleRate;

@end


#pragma mark -- QNLocalAudioTrack
@interface QNLocalAudioTrack : QNLocalTrack

/*!
 * @abstract 音频 Track 回调代理。
 *
 * @since v4.0.0
 */
@property (nonatomic, weak) id<QNLocalAudioTrackDelegate> audioDelegate;

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 输入音量
 *
 * @discussion 设置范围为 0~10，默认为 1
 *
 * @warning 当麦克风输入音量增益调大之后，部分机型会出现噪音
 *
 * @since v4.0.0
 */
- (void)setVolume:(double)volume;

/*!
 * @abstract 用户音量回调，volume 值在 [0, 1] 之间。
 *
 * @since v4.0.1
 */
- (float)getVolumeLevel;

@end

#pragma mark -- QNMicrophoneAudioTrack
@interface QNMicrophoneAudioTrack : QNLocalAudioTrack

- (instancetype)init NS_UNAVAILABLE;

@end

#pragma mark -- QNCustomAudioTrack
@interface QNCustomAudioTrack : QNLocalAudioTrack

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 导入音频数据
 *
 * @discussion 仅在调用 - (void)setExternalAudioSourceEnabled:(BOOL)enabled; 并传入 YES 后才有效。
 * 支持的音频数据格式为：PCM 格式，48000 采样率，16 位宽，单声道
 *
 * @since v4.0.0
 */
- (void)pushAudioBuffer:(AudioBuffer *)audioBuffer;

/*!
 * @abstract 导入音频数据
 *
 * @discussion 仅在调用 - (void)setExternalAudioSourceEnabled:(BOOL)enabled; 并传入 YES 后才有效。
 * 支持的音频数据格式为：PCM 格式
 *
 * @since v4.0.0
 */
- (void)pushAudioBuffer:(AudioBuffer *)audioBuffer asbd:(AudioStreamBasicDescription *)asbd;


@end

#pragma mark -- QNLocalVideoTrackDelegate
@class QNLocalVideoTrack;
@protocol QNLocalVideoTrackDelegate <NSObject>

@optional
/*!
 * @abstract 视频 Track 数据回调。
 *
 * @since v4.0.0
 */
- (void)localVideoTrack:(QNLocalVideoTrack *)localVideoTrack didGetPixelBuffer:(CVPixelBufferRef)pixelBuffer;

@end

#pragma mark -- QNLocalVideoTrack
@interface QNLocalVideoTrack : QNLocalTrack

@property (nonatomic, weak) id<QNLocalVideoTrackDelegate> videoDelegate;

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 本地视频 Track 添加 SEI
 *
 * @param videoSEI SEI 内容
 *
 * @param uuid  自定义设置 uuid
 *
 * @param repeatNumber SEI 重复发送次数，-1 为永久发送
 *
 * @discussion 需要停止发送 SEI，可以设置 videoSEI 为 nil，repeatNumber 为 0 即可
 *
 * @since v4.0.0
 */
- (void)sendSEI:(NSString *)videoSEI
           uuid:(NSString *)uuid
   repeatNmuber:(NSNumber *)repeatNumber;

/*!
 * @abstract 视频 Track 渲染。
 *
 * @since v4.0.0
 */
- (void)play:(QNVideoGLView *)videoView;

@end


#pragma mark -- QNCameraVideoTrack
@interface QNCameraVideoTrack : QNLocalVideoTrack

/*!
 * @abstract 摄像头的位置，默认为 AVCaptureDevicePositionFront。需在 config 中设置
 *
 * @since v4.0.0
 */
@property (nonatomic, assign, readonly) AVCaptureDevicePosition captureDevicePosition;

/*!
 * @abstract 开启 camera 时的采集摄像头的旋转方向，默认为 AVCaptureVideoOrientationPortrait。
 *
 * @since v4.0.0
 */
@property (nonatomic, assign) AVCaptureVideoOrientation videoOrientation;

/*!
 * @abstract 是否开启手电筒，默认为 NO。
 *
 * @since v4.0.0
 */
@property (nonatomic, assign, getter=isTorchOn) BOOL torchOn;

/*!
 * @abstract 连续自动对焦。默认为 YES。
 *
 * @since v4.0.0
 */
@property (nonatomic, assign, getter=isContinuousAutofocusEnable) BOOL continuousAutofocusEnable;

/*!
 * @abstract 聚焦的位置，(0,0) 代表左上, (1,1) 代表右下。默认为 (0.5, 0.5)，即中间位置。
 *
 * @since v4.0.0
 */
@property (nonatomic, assign) CGPoint focusPointOfInterest;

/*!
 * @abstract 控制摄像头的缩放，默认为 1.0。
 *
 * @discussion 设置的数值需要小于等于 videoActiveForat.videoMaxZoomFactor，如果大于会设置失败。
 *
 * @since v4.0.0
 */
@property (nonatomic, assign) CGFloat videoZoomFactor;

/*!
 * @abstract 设备支持的 formats。
 *
 * @since v4.0.0
 */
@property (nonatomic, strong, readonly) NSArray<AVCaptureDeviceFormat *> *videoFormats;

/*!
 * @abstract 设备当前的 format。
 *
 * @since v4.0.0
 */
@property (nonatomic, strong) AVCaptureDeviceFormat *videoActiveFormat;

/*!
 * @abstract 采集的视频的 sessionPreset，默认为 AVCaptureSessionPreset640x480。
 *
 * @since v4.0.0
 */
@property (nonatomic, copy) NSString *sessionPreset;

/*!
 * @abstract 采集的视频数据的帧率，默认为 24。
 *
 * @since v4.0.0
 */
@property (nonatomic, assign) NSUInteger videoFrameRate;

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 切换前后摄像头。
 *
 * @since v4.0.0
 */
- (void)switchCamera;

/*!
 * @abstract 是否开启美颜。
 *
 * @since v4.0.0
 */
- (void)setBeautifyModeOn:(BOOL)beautifyModeOn;

/*!
 * @abstract 设置对应 Beauty 的程度参数，范围从 0 ~ 1，0 为不美颜。
 *
 * @discussion 如果美颜不开启，设置该参数无效。
 *
 * @since v4.0.0
 */
- (void)setBeautify:(CGFloat)beautify;

/*!
 * @abstract 设置美白程度。
 *
 * @discussion 如果美颜不开启，设置该参数无效。
 *
 * @since v4.0.0
 */
- (void)setWhiten:(CGFloat)whiten;

/*!
 * @abstract 设置红润的程度。范围是从 0 ~ 1，0 为不红润。
 *
 * @discussion 如果美颜不开启，设置该参数无效。
 *
 * @since v4.0.0
 */
- (void)setRedden:(CGFloat)redden;

/*!
 * @abstract 设置水印。
 *
 * @since v4.0.0
 */
- (void)setWaterMarkWithImage:(UIImage *)waterMarkImage position:(CGPoint)position;

/*!
 * @abstract 移除水印。
 *
 * @since v4.0.0
 */
- (void)clearWaterMark;

/*!
 * @abstract 设置摄像头 track 发送图片数据
 *
 * @param image 推流的图片
 *
 * @discussion 由于某些特殊原因不想使用摄像头采集的数据作为发送视频数据时，可以使用该接口设置一张图片来替代。传入 nil 则关闭该功能。
 * @warning    请确保传入的 image 的宽和高是 16 的整数倍。请勿在 applicationState 为 UIApplicationStateBackground 时调用该接口，否则将出错。
 *
 * @since v4.0.0
 */
- (void)pushImage:(nullable UIImage *)image;

/*!
 * @abstract 开启摄像头采集。
 *
 * @since v4.0.0
 */
- (void)startCapture;

/*!
 * @abstract 关闭摄像头采集。
 *
 * @since v4.0.0
 */
- (void)stopCapture;

@end


@class QNScreenVideoTrack;
@protocol QNScreenVideoTrackDelegate <NSObject>

@optional

/*!
 * @abstract 录屏运行过程中发生错误会通过该方法回调。
 *
 * @since v4.0.0
 */
- (void)screenVideoTrack:(QNScreenVideoTrack *)screenVideoTrack didFailWithError:(NSError *)error;

@end

#pragma mark -- QNScreenVideoTrack
@interface QNScreenVideoTrack : QNLocalVideoTrack

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 判断屏幕共享功能是否可用
 *
 * @discussion 屏幕共享功能仅在 iOS 11 及以上版本可用
 *
 * @since v4.0.0
 */
+ (BOOL)isScreenRecorderAvailable;

/*!
 * @abstract 录屏 Track 回调代理。
 *
 * @since v4.0.0
 */
@property (nonatomic, weak) id<QNScreenVideoTrackDelegate> screenDelegate;

@end

#pragma mark -- QNCustomVideoTrack
@interface QNCustomVideoTrack : QNLocalVideoTrack

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 导入视频数据。
 *
 * @discussion 调用此接口将把数据导入给所有 sourceType 为 QNRTCSourceTypeExternalVideo 的视频 Track。
 * 支持导入的视频数据格式为：kCVPixelFormatType_420YpCbCr8BiPlanarFullRange
 * 和 kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange。
 *
 * @since v4.0.0
 */
- (void)pushVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer;

/*!
 * @abstract 导入视频数据。
 *
 * @discussion 调用此接口将把数据导入给所有 sourceType 为 QNRTCSourceTypeExternalVideo 的视频 Track。
 * 支持导入的视频数据格式为：kCVPixelFormatType_420YpCbCr8BiPlanarFullRange
 * 和 kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange。
 *
 * @since v4.0.0
 */
- (void)pushPixelBuffer:(CVPixelBufferRef)pixelBuffer;

@end


@class QNRemoteTrack;
@protocol QNRemoteTrackDelegate <NSObject>

@optional

/*!
 * @abstract 订阅的远端 Track 开关静默时的回调。
 *
 * @since v4.0.0
 */
- (void)remoteTrack:(QNRemoteTrack *)remoteTrack didMutedByRemoteUserID:(NSString *)userID;

/*!
 * @abstract 订阅的远端视频 Track 分辨率发生变化时的回调。
 *
 * @since v4.0.0
 */
- (void)remoteTrack:(QNRemoteTrack *)remoteTrack didSubscribeProfileChanged:(QNTrackProfile)profile;

@end

#pragma mark -- QNRemoteTrack
@interface QNRemoteTrack : QNTrack

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 远端 Track 回调代理。
 *
 * @since v4.0.0
 */
@property (nonatomic, weak) id<QNRemoteTrackDelegate> remoteDelegate;

/*!
 * @abstract 是否已订阅。
 *
 * @since v4.0.0
 */
@property (nonatomic, readonly) BOOL isSubscribed;

@end

@class QNRemoteAudioTrack;
@protocol QNRemoteAudioTrackDelegate <NSObject>

/*!
 * @abstract 音频 Track 数据回调。
 *
 * @since v4.0.0
 */
- (void)remoteAudioTrack:(QNRemoteAudioTrack *)remoteAudioTrack didGetAudioBuffer:(AudioBuffer *)audioBuffer bitsPerSample:(NSUInteger)bitsPerSample sampleRate:(NSUInteger)sampleRate;

@end

#pragma mark -- QNRemoteAudioTrack
@interface QNRemoteAudioTrack : QNRemoteTrack

// aaron need to consider
@property (nonatomic, weak) id<QNRemoteAudioTrackDelegate> audioDelegate;

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 设置远端音频 Track 播放音量。范围从 0 ~ 10，10 为最大
 *
 * @discussion 需要发布成功后才可以执行 setRemote 操作。本次操作仅对远端音频播放音量做调整，远端音量回调为远端音频数据的原始音量，不会基于本设置做相应调整。
 *
 * @warning 部分机型调整音量放大会出现低频噪音
 *
 * @since  v4.0.0
 */
- (void)setVolume:(double)volume;

/*!
 * @abstract 用户音量回调，volume 值在 [0, 1] 之间。
 *
 * @since v4.0.1
 */
- (float)getVolumeLevel;

@end

@class QNRemoteVideoTrack;
@protocol QNRemoteVideoTrackDelegate <NSObject>

@optional
/*!
 * @abstract 视频 Track 数据回调。
 *
 * @since v4.0.0
 */
- (void)remoteVideoTrack:(QNRemoteVideoTrack *)remoteVideoTrack didGetPixelBuffer:(CVPixelBufferRef)pixelBuffer;

@end

#pragma mark -- QNRemoteVideoTrack
@interface QNRemoteVideoTrack : QNRemoteTrack

/*!
 * @abstract 视频 Track 回调代理。
 *
 * @since v4.0.0
 */
@property (nonatomic, weak) id<QNRemoteVideoTrackDelegate> videoDelegate;

/*!
 * @abstract 是否开启大小流。
 *
 * @since v4.0.0
 */
@property (nonatomic, readonly) BOOL isMultiProfileEnabled;

- (instancetype)init NS_UNAVAILABLE;

/*!
 * @abstract 变更订阅大小流等级。
 *
 * @since v4.0.0
 */
- (void)setProfile:(QNTrackProfile)profile;

/*!
 * @abstract 视频 Track 渲染。
 *
 * @since v4.0.0
 */
- (void)play:(QNVideoGLView *)videoView;

@end

NS_ASSUME_NONNULL_END
