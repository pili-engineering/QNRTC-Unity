//
//  QNRTCVideoView.h
//  QNRTCKit
//
//  Created by lawder on 2017/10/24.
//  Copyright © 2017年 Pili Engineering, Qiniu Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
 #import "QNTypeDefines.h"

@interface QNVideoGLView : UIView

@property(nonatomic, assign) QNVideoFillModeType fillMode;

@end
